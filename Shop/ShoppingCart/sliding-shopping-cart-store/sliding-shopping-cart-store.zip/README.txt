A Pen created at CodePen.io. You can find this one at https://codepen.io/heyitsolivia/pen/CaJFA.

 Responsive hidden/sliding shopping cart. Add items from the store, update quantities and removing items (by setting quantity to 0). Have fun exploring!

Crafted for the shopping cart Pattern Rodeo challenge, images belong to Github.