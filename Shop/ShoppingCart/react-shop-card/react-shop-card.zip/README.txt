A Pen created at CodePen.io. You can find this one at https://codepen.io/OlgaKoplik/pen/mYWReQ.

 React  Donut Shop Card with success message and product color change