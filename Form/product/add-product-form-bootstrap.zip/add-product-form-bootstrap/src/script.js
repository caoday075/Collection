$(document).ready(function(){
  // jquery code here
  
});