A Pen created at CodePen.io. You can find this one at https://codepen.io/mimikos/pen/JyYoEe.

 venetian blinds effect | image hover | set number of columns | 3d transform

image by paul fuentes
http://www.paulfuentesdesign.com/work/#/new-gallery-4/